GitHub -> FastAPI -> Tree-sitter -> Semgrep -> AI -> PR Comments
