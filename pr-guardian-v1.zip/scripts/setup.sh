#!/bin/bash
echo setup
