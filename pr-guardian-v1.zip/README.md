# PR Guardian V1
Evidence-first GitHub PR review bot scaffold.
