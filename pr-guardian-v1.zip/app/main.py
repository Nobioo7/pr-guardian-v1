from fastapi import FastAPI
app=FastAPI(title='PR Guardian V1')
@app.get('/')
def root(): return {'status':'ok'}
